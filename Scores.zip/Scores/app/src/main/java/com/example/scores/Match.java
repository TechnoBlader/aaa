package com.example.scores;

public class Match {
    protected Team t1;
    protected Team t2;
    protected int scoreT1;
    protected int scoreT2;

    public Match(Team t1, Team t2, int scoreT1, int scoreT2){
        this.t1 = t1;
        this.t2 = t2;
        this.scoreT1 = scoreT1;
        this.scoreT2 = scoreT2;
    }

    public Team getT1(){
        return this.t1;
    }

    public Team getT2(){
        return this.t2;
    }

    public int getScoreT1(){
        return this.scoreT1;
    }

    public int getScoreT2(){
        return this.scoreT2;
    }

    //gets the score and gives points for win / draw / lose. also, changes the goals counts.
    public void matchEnd(){
        System.out.println(this.t1.getName() + ": " + this.scoreT1 + " - " + this.scoreT2 + " :" + this.t2.getName());
        t1.setGoalsScored(t1.getGoalsScored() + this.scoreT1);
        t1.setGoalsAgainst(t1.getGoalsAgainst() + this.scoreT2);
        t2.setGoalsScored(t2.getGoalsScored() + this.scoreT2);
        t2.setGoalsAgainst(t2.getGoalsAgainst() + this.scoreT1);

        if(this.scoreT1 > this.scoreT2){
            t1.setWins(t1.getWins() + 1);
            t2.setLosses(t2.getLosses() + 1);
            System.out.println(t1.getName() + " won!");
        }
        else
        if(this.scoreT1 < this.scoreT2){
            t2.setWins(t2.getWins() + 1);
            t1.setLosses(t1.getLosses() + 1);
            System.out.println(t2.getName() + " won!");
        }
        else{
            t2.setDraws(t2.getDraws() + 1);
            t1.setDraws(t1.getLosses() + 1);
            System.out.println("its a draw!");
        }
    }
}
