package com.example.scores;

public class LeagueTable {
    protected String name;
    protected Team[] teams;
    protected Round[] rounds;

    public LeagueTable(String name, int num){
        this.name = name;
        this.teams = new Team[num];
        this.rounds = new Round[(this.teams.length - 1) * 2];
        for(int i = 0; i < this.rounds.length; i++){
            rounds[i] = new Round(this.teams.length / 2);
        }
    }

    public void addMatch(Match m, int Round_num){
        rounds[Round_num - 1].add(m);
    }

    public void addTeam(Team t){
        boolean init = false;
        for(int i = 0; i < this.teams.length; i++){
            if (this.teams[i] == null && !init){
                init = true;
                this.teams[i] = t;
            }
        }
    }

    public void arrangeTable(){
        boolean init = false;
        Team[] copy = new Team[this.teams.length];
//Reset the copy
        for(int k = 0; k < this.teams.length; k++){
            copy[k] = null;
        }
        copy[0] = this.teams[0];
        for(int i = 1; i < this.teams.length; i++){
            for(int j = 0; j < this.teams.length; j++){
                if(this.teams[i] == null){
                }
                else
//check the points to see if its equal or teams has bigger
// if bigger:
                    if(copy[j] != null && copy[j].getPoints() < this.teams[i].getPoints() && !init){
                        if (copy[j + 1] == null){
                            copy[j+1] = copy[j];
                            copy[j] = this.teams[i];
                            init = true;
                        }
                        else
                            for(int s = this.teams.length - 2; s >= 0; s--){
                                if(!init){
                                    copy[s+1] = copy[s];
                                    if (s == j){
                                        copy[j] = this.teams[i];
                                        init = true;
                                    }
                                }
                            }
                    }
                    else
// if equal:
                        if(copy[j] != null && copy[j].getPoints() == this.teams[i].getPoints() && !init){
                            if(copy[j].getAllGoals() < this.teams[i].getAllGoals()){
                                if (j == this.teams.length - 1){
                                    copy[j] = this.teams[i];
                                }
                                else
                                if (copy[j + 1] == null){
                                    copy[j + 1] = copy[j];
                                    copy[j] = this.teams[i];
                                    init = true;
                                }
                                else
                                    for(int s = this.teams.length - 2; s >= 0; s--){
                                        if(!init){
                                            copy[s+1] = copy[s];
                                            if (s == j){
                                                copy[j] = this.teams[i];
                                                init = true;
                                            }
                                        }
                                    }
                            }
                        }
                        else
                        if(copy[j] == null && !init){
                            copy[j] = this.teams[i];
                            init = true;
                        }
            }
            init = false;
        }
        for(int u = 0; u < this.teams.length; u++){
            if(copy[u] != null){
                this.teams[u] = copy[u];
            }
        }
    }

    public void printTable(){
        for(int i = 0; i < this.teams.length; i++){
            if(this.teams[i] != null)
                System.out.println(this.teams[i].getName() + " " + this.teams[i].getPoints() + " " + this.teams[i].getAllGoals());
        }

    }
}
