package com.example.scores;

public class Team {
    private String name;
    private int points;
    private int wins;
    private int draws;
    private int losses;
    private int goalsScored;
    private int goalsAgainst;
    private int allGoals;

    public Team(String name){
        this.name = name;
        this.points = 0;
        this.wins = 0;
        this.draws = 0;
        this.losses = 0;
        this.goalsScored = 0;
        this.goalsAgainst = 0;
        this.allGoals = 0;
    }

    public void setPoints(){
        this.points = (this.wins * 3 + this.draws);
    }

    public int getPoints(){
        setPoints();
        return this.points;
    }

    public void setGoalsScored(int num){
        this.goalsScored = num;
        setAllGoals();
    }

    public int getGoalsScored(){
        return this.goalsScored;
    }

    public void setGoalsAgainst(int num){
        this.goalsAgainst = num;
        setAllGoals();
    }

    public int getGoalsAgainst(){
        setAllGoals();
        return this.goalsAgainst;
    }

    public void setAllGoals(){
        this.allGoals = this.goalsScored - this.goalsAgainst;
    }

    public int getAllGoals(){
        return this.allGoals;
    }

    public void setWins(int num){
        this.wins = num;
        setPoints();
    }

    public int getWins(){
        return this.wins;
    }

    public void setDraws(int num){
        this.draws = num;
        setPoints();
    }

    public int getDraws(){
        return this.draws;
    }

    public void setLosses(int num){
        this.losses = num;
    }

    public int getLosses(){
        return this.losses;
    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

    public boolean moreGoals(Team t1){
        if(this.getAllGoals() > t1.getAllGoals())
            return true;
        else
            return false;
    }

}
