package com.example.scores;

public class Round {
    protected Match[] matches;

    public Round(int num){
        matches = new Match[num];
    }

    public void add(Match m){
        boolean init = false;
        for(int i = 0; i < this.matches.length; i++){
            if (this.matches[i] == null && !init){
                init = true;
                this.matches[i] = m;
            }
        }
    }
}
